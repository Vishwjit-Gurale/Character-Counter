const textarea = document.querySelector(".text-area");
const charelement = document.querySelector(".char-number");
const wordelement = document.querySelector(".word-number");
const twitterelement = document.querySelector(".twitter-number");
const instaelement = document.querySelector(".insta-number");

let twitterlimit = 280;
let instalimit = 160;

// char function
const charcounter = (e) => {
  console.log(e);
  charelement.innerText = e.target.value.length;
};

// word function

const wordcounter = (e) => {
  let str = e.target.value;
  str = str.trim();
  str = str.split(" ");
  console.log(str);
  wordelement.innerText = str.length;
};

// twitter function

const twittercounter = (e) => {
  twitterelement.innerText = twitterlimit - e.target.value.length;
};

// insta function

const instacounter = (e) => {
  instaelement.innerText = instalimit - e.target.value.length;
};

// main function
textarea.addEventListener("input", (e) => {
  charcounter(e);
  twittercounter(e);
  instacounter(e);
  wordcounter(e);
});
